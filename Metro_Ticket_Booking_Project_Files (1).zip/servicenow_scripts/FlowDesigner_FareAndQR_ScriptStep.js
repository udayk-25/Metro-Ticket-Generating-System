// Flow Designer Script step: validate inputs and prepare a booking payload.
// Inputs expected from the flow: origin_sequence, destination_sequence,
// passenger_count, base_fare, per_station_fare, minimum_fare, ticket_id.
(function execute(inputs, outputs) {
    try {
        var fare = new MetroFareService().calculate(
            inputs.origin_sequence,
            inputs.destination_sequence,
            inputs.passenger_count,
            inputs.base_fare,
            inputs.per_station_fare,
            inputs.minimum_fare
        );

        outputs.success = true;
        outputs.fare_amount = fare.totalFare;
        outputs.fare_per_passenger = fare.farePerPassenger;
        outputs.station_intervals = fare.intervals;
        outputs.currency = fare.currency;
        outputs.qr_payload = 'METRO-DEMO:TICKET:' + String(inputs.ticket_id);
        outputs.error_message = '';
    } catch (e) {
        outputs.success = false;
        outputs.fare_amount = 0;
        outputs.qr_payload = '';
        outputs.error_message = e.message || 'Booking validation failed.';
    }
})(inputs, outputs);
