// Catalog Client Script (onChange) for destination_station.
// UX helper only; repeat all checks on the server.
function onChange(control, oldValue, newValue, isLoading) {
    if (isLoading || !newValue) return;
    var origin = g_form.getValue('origin_station');
    if (origin && origin === newValue) {
        g_form.showFieldMsg('destination_station',
            'Origin and destination must be different.', 'error');
        g_form.setValue('destination_station', '');
    }
}
