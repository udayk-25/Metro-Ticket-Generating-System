// Script Include: MetroFareService
// Prototype only. Adapt table/field names and fare policy for your ServiceNow instance.
var MetroFareService = Class.create();
MetroFareService.prototype = {
    initialize: function() {},

    calculate: function(originSequence, destinationSequence, passengerCount, baseFare, perStationFare, minimumFare) {
        var origin = parseInt(originSequence, 10);
        var destination = parseInt(destinationSequence, 10);
        var passengers = parseInt(passengerCount, 10);
        var base = parseFloat(baseFare);
        var perStation = parseFloat(perStationFare);
        var minFare = parseFloat(minimumFare);

        if (isNaN(origin) || isNaN(destination) || origin === destination)
            throw new Error('Choose two different valid stations.');
        if (isNaN(passengers) || passengers < 1 || passengers > 10)
            throw new Error('Passenger count must be between 1 and 10.');
        if (isNaN(base) || isNaN(perStation) || isNaN(minFare) || base < 0 || perStation < 0 || minFare < 0)
            throw new Error('Fare configuration is invalid.');

        var intervals = Math.abs(destination - origin);
        var perPassenger = Math.max(minFare, base + (perStation * intervals));
        return {
            intervals: intervals,
            farePerPassenger: Math.round(perPassenger * 100) / 100,
            totalFare: Math.round(perPassenger * passengers * 100) / 100,
            currency: 'INR'
        };
    },

    type: 'MetroFareService'
};
