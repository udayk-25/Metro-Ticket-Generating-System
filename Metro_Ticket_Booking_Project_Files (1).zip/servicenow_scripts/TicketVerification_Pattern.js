// Server-side validation pattern for a ticket verification endpoint.
// Do not accept the QR payload as proof by itself. Resolve ticket ID against
// the trusted ticket table and enforce status/validity/reuse policy.
(function verifyTicket(ticketId) {
    if (!ticketId) return { valid: false, reason: 'missing_ticket_id' };

    var ticket = new GlideRecord('x_metro_booking');
    ticket.addQuery('ticket_id', ticketId);
    ticket.setLimit(1);
    ticket.query();

    if (!ticket.next()) return { valid: false, reason: 'not_found' };
    if (ticket.getValue('ticket_status') !== 'Confirmed')
        return { valid: false, reason: 'not_confirmed' };

    // TODO: compare travel_date / valid_from / valid_until with current time.
    // TODO: apply single-use policy atomically to prevent repeated scans.
    return { valid: true, ticket_number: ticket.getValue('number') };
})(/* pass decoded ticket ID here */);
